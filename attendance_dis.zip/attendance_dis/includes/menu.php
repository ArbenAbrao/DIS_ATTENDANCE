<?php 
require_once __DIR__ . '/../config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Attendance System</title>
    <link rel="stylesheet" href="main.css" />
    <link rel="shortcut icon" href="img/logo.png" />
    <style>
     
    </style>
</head>
<body>

<!-- Header -->
<header class="main-header">
    <div class="nav-left">
        <button class="toggle-btn">☰</button>
        <a href="index.php" class="main-header__brand">Attendance</a>
    </div>
    <nav class="main-nav">
        <ul class="main-nav__items">
            <button id="promoteStudentsBtn" class="nav-btn">Promote Students</button>
            <button id="historyBtn" class="nav-btn">History</button>
            <a class="nav-btn" href="index.php">Home</a>
            <a class="nav-btn" href="logout.php">Log Out</a>
        </ul>
    </nav>
</header>

<!-- Main Container -->
<div class="container">

    <!-- Sidebar -->
    <aside class="sidebar">
        <label for="gradeSelect" class="sidebar-label">Select Employee/Grade Level:</label>
        <select id="gradeSelect" onchange="loadGradeAttendance()">
            <option value="">- Select Department -</option>
            <optgroup label="Grade Levels">
                <?php
                $grades = range(1, 12);
                echo '<option value="Nursery">Nursery</option>';
                echo '<option value="Kinder">Kinder</option>';
                foreach ($grades as $grade) {
                    echo "<option value=\"Grade $grade\">Grade $grade</option>";
                }
                ?>
            </optgroup>
            <optgroup label="Employee">
                <option value="Admin">Admin</option>
                <option value="Faculty">Faculty</option>
                <option value="Guard">Guards</option>
            </optgroup>
        </select>
    </aside>

    <!-- Content -->
    <div class="content">
        <div id="attendance-section">
            <div class="top-controls">
                <button id="addStudentBtn" class="nav-btn" style="display: none;" onclick="openAddStudentModal()">+ Add Names</button>
                <input type="text" id="searchBar" class="searchBar" style="display: none;" onkeyup="searchStudents()" placeholder="Search student...">
            </div>
            <div id="attendance-content">
                <table id="studentTable">
                    <thead><tr></tr></thead>
                    <tbody id="studentTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Student Modal -->
<div id="addStudentModal" class="addstudentmodal">
    <div class="addstudentmodal-content">
        <span class="close-btn" onclick="closeAddStudentModal()">&times;</span>
        <h2>Add Multiple Students</h2>
        <form id="addStudentForm">
            <div id="studentInputs">
                <div class="student-input">
                    <input type="text" name="studentNames[]" class="addstudentmodal-input" placeholder="Enter student name" required>
                    <button type="button" class="remove-btn" onclick="removeStudentInput(this)">×</button>
                </div>
            </div>
            <button type="button" onclick="addStudentInput()" class="nav-btn">Add More</button>
            <input type="hidden" id="selectedGrade">
            <button type="submit" class="nav-btn">Save All</button>
        </form>
    </div>
</div>

<!-- History Modal -->
<div id="historyModal" class="history-modal">
    <div class="history-modal-content">
        <span class="close-btn" onclick="closeHistoryModal()">&times;</span>
        <h2>Attendance History</h2>

        <div class="history-controls">
            <input type="text" id="historySearchBar" placeholder="Search history...">
            <select id="historyGradeSelect">
                <option value="">All Grades</option>
                <option value="Nursery">Nursery</option>
                <option value="Kinder">Kinder</option>
                <?php foreach (range(1, 12) as $grade): ?>
                    <option value="Grade <?= $grade ?>">Grade <?= $grade ?></option>
                <?php endforeach; ?>
            </select>
            <select id="historyEmployeeSelect">
                <option value="">All Employees</option>
                <option value="Admin">Admin</option>
                <option value="Faculty">Faculty</option>
                <option value="Guard">Guards</option>
            </select>
            <!-- Date Picker Added -->
            <input type="date" id="historyDatePicker">
        </div>

        <div id="historyContent">
            <p>Enter a name and press Enter to view history.</p>
        </div>
    </div>
</div>






<!-- JavaScript Section -->
<script>
document.getElementById("promoteStudentsBtn").addEventListener("click", () => {
    if (confirm("Are you sure you want to promote students?")) {
        fetch("promote_students.php", { method: "POST" })
        .then(res => res.json())
        .then(data => {
            alert(data.success ? "Updated!" : "Error: " + data.message);
            if (data.success) loadGradeAttendance();
        })
        .catch(console.error);
    }
});

function addStudentInput() {
    const container = document.getElementById("studentInputs");
    const newInput = document.createElement("div");
    newInput.classList.add("student-input");
    newInput.innerHTML = `
        <input type="text" name="studentNames[]" class="addstudentmodal-input" placeholder="Enter student name" required>
        <button type="button" class="remove-btn" onclick="removeStudentInput(this)">×</button>`;
    container.appendChild(newInput);
}

function removeStudentInput(button) {
    button.parentElement.remove();
}

document.getElementById("addStudentForm").addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append("grade", document.getElementById('selectedGrade').value);

    fetch("add_student.php", { method: "POST", body: formData })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                closeAddStudentModal();
                loadGradeAttendance();
            }
        })
        .catch(console.error);
});

function loadGradeAttendance() {
    const grade = document.getElementById('gradeSelect').value;
    const addBtn = document.getElementById('addStudentBtn');
    const searchBar = document.getElementById('searchBar');
    document.getElementById('selectedGrade').value = grade;

    if (grade) {
        fetch("attendance.php?grade=" + encodeURIComponent(grade))
            .then(res => res.text())
            .then(data => {
                document.getElementById('studentTableBody').innerHTML = data;
            });
        addBtn.style.display = "block";
        searchBar.style.display = "block";
    } else {
        addBtn.style.display = "none";
        searchBar.style.display = "none";
        document.getElementById('studentTableBody').innerHTML = "";
    }
}

function searchStudents() {
    const input = document.getElementById('searchBar').value.toLowerCase();
    const rows = document.querySelectorAll("#studentTableBody tr");
    rows.forEach(row => {
        const name = row.cells[0]?.innerText.toLowerCase() || "";
        row.style.display = name.includes(input) ? "" : "none";
    });
}

function openAddStudentModal() {
    document.getElementById('addStudentModal').style.display = "flex";
}

function closeAddStudentModal() {
    document.getElementById('addStudentModal').style.display = "none";
}





// Open the modal
document.getElementById("historyBtn").addEventListener("click", () => {
    document.getElementById("historyModal").style.display = "flex";
    document.getElementById("historyContent").innerHTML = "<p>Enter a name and press Enter to view history.</p>";
    document.getElementById("historySearchBar").value = "";
});

// Close modal
function closeHistoryModal() {
    document.getElementById("historyModal").style.display = "none";
}

// Trigger fetch on Enter
document.getElementById("historySearchBar").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
        fetchHistory();
    }
});

// Filters trigger fetch if name is entered
document.getElementById("historyGradeSelect").addEventListener("change", () => {
    if (document.getElementById("historySearchBar").value.trim()) {
        fetchHistory();
    }
});

document.getElementById("historyEmployeeSelect").addEventListener("change", () => {
    if (document.getElementById("historySearchBar").value.trim()) {
        fetchHistory();
    }
});

// Trigger fetch on Enter
document.getElementById("historySearchBar").addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
        fetchHistory();
    }
});

// Trigger fetch if any filter changes (Grade, Employee, Date)
document.getElementById("historyGradeSelect").addEventListener("change", fetchHistory);
document.getElementById("historyEmployeeSelect").addEventListener("change", fetchHistory);
document.getElementById("historyDatePicker").addEventListener("change", fetchHistory);

// Fetch history and render table
function fetchHistory() {
    const search = document.getElementById("historySearchBar").value.trim();
    const grade = document.getElementById("historyGradeSelect").value;
    const employee = document.getElementById("historyEmployeeSelect").value;
    const date = document.getElementById("historyDatePicker").value; // Get the selected date

    if (!search) {
        document.getElementById("historyContent").innerHTML = "<p>Please enter a name to search.</p>";
        return;
    }

    const params = new URLSearchParams({
        search: search,
        grade: grade,
        type: employee,
        date: date, // Include the selected date
    });

    fetch(`history.php?${params.toString()}`)
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById("historyContent");
            if (data.length === 0) {
                container.innerHTML = "<p>No records found.</p>";
                return;
            }

            let html = `
                <div class="scrollable-table">
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Grade/Type</th>
                                <th>Date</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                            </tr>
                        </thead>
                        <tbody>
            `;

            data.forEach(row => {
                html += `
                    <tr>
                        <td>${row.name}</td>
                        <td>${row.grade_level}</td>
                        <td>${row.date}</td>
                        <td>${row.time_in_id || "-"}</td>
                        <td>${row.time_out_id || "-"}</td>
                    </tr>
                `;
            });

            html += `
                        </tbody>
                    </table>
                </div>
            `;

            container.innerHTML = html;
        })
        .catch(error => {
            console.error(error);
            document.getElementById("historyContent").innerHTML = "<p>Error loading data.</p>";
        });
}

</script>

<script src="script.js"></script>

<!-- Footer -->
<footer class="footer-container">
    <small><i>@2025 DIS</i></small>
</footer>
</body>
</html>
