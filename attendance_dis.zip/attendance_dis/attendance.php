<?php
require_once __DIR__ . '/config.php';


$grade_level = isset($_GET['grade']) ? $_GET['grade'] : '';

if (!$grade_level) {
    echo "<p>Please select a grade level.</p>";
    exit;

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $id = $_POST['id'];
    
        if ($_POST['action'] == "time_in") {
            $time_in = date("H:i:s");
            $query = "UPDATE attendance SET time_in='$time_in' WHERE id='$id'";
            mysqli_query($conn, $query);
            echo json_encode(["time_in" => $time_in]);
        }
    
        if ($_POST['action'] == "time_out") {
            $time_out = date("H:i:s");
            $query = "UPDATE attendance SET time_out='$time_out' WHERE id='$id'";
            mysqli_query($conn, $query);
            echo json_encode(["time_out" => $time_out]);
        }
    
        if ($_POST['action'] == "delete") {
            $query = "DELETE FROM attendance WHERE id='$id'";
            mysqli_query($conn, $query);
            echo json_encode(["status" => "deleted"]);
        }
    }
}

echo "<h2>$grade_level Attendance</h2>";
?>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Time In</th>
            <th>Time Out</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody id="studentTableBody">
        <?php
       $query = "SELECT students.id, students.name,
       COALESCE(MAX(attendance.time_in_am), '') AS time_in, 
       COALESCE(MAX(attendance.time_out_pm), '') AS time_out
FROM students 
LEFT JOIN attendance 
ON students.id = attendance.student_id 
AND attendance.date = CURDATE()
WHERE students.grade_level = ?
GROUP BY students.id, students.name";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $grade_level);
$stmt->execute();
$result = $stmt->get_result();


        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr data-id='{$row['id']}'>
                        <td>{$row['name']}</td>
                        <td class='time-in'>{$row['time_in']}</td>
                        <td class='time-out'>{$row['time_out']}</td>
                        <td>
                            <button class='in-btn'>In</button>
                            <button class='out-btn'>Out</button>
                            <button class='delete-btn'>Delete</button>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No students added yet.</td></tr>";
        }
        ?>
    </tbody>
</table>

<script src="script.js"></script>
