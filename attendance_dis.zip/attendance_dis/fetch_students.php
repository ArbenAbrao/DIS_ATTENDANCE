<?php
include 'config.php';

$result = $conn->query("SELECT * FROM attendance ORDER BY id DESC");
$students = [];

while ($row = $result->fetch_assoc()) {
    $students[] = $row;
}

echo json_encode($students);
$conn->close();
?>
