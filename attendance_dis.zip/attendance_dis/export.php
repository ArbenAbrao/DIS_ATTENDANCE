<?php
// Enable PHP error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Autoload PhpSpreadsheet
require 'vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;

// Connect to database
$conn = new mysqli("localhost", "root", "", "attendance_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set timezone
date_default_timezone_set('Asia/Manila');

// Get current time
$currentTime = date("h:i A");

// Fetch only unexported attendance data for today
$query = "SELECT students.name, students.grade_level, 
                 COALESCE(attendance.time_in_am, '') AS time_in, 
                 COALESCE(attendance.time_out_pm, '') AS time_out,
                 attendance.student_id
          FROM students
          LEFT JOIN attendance 
          ON students.id = attendance.student_id 
          AND attendance.date = CURDATE()
          AND attendance.exported = 0
          WHERE attendance.student_id IS NOT NULL
          ORDER BY students.grade_level ASC, students.name ASC";

$result = $conn->query($query);

// Group data by grade level
$gradeLevels = [];
$studentIdsToMark = [];

while ($data = $result->fetch_assoc()) {
    $grade = $data['grade_level'];
    if (!isset($gradeLevels[$grade])) {
        $gradeLevels[$grade] = [];
    }
    $gradeLevels[$grade][] = $data;

    // Collect student IDs for post-processing
    $studentIdsToMark[] = $data['student_id'];
}

// Prepare spreadsheet
$spreadsheet = new Spreadsheet();
$sheetIndex = 0;

foreach ($gradeLevels as $grade => $students) {
    $sheet = ($sheetIndex === 0) ? $spreadsheet->getActiveSheet() : $spreadsheet->createSheet();
    $sheet->setTitle($grade);

    // Headers
    $sheet->setCellValue('A1', 'Student Name');
    $sheet->setCellValue('B1', 'Time In');
    $sheet->setCellValue('C1', 'Time Out');

    $sheet->getStyle('A1:C1')->applyFromArray([
        'font' => ['bold' => true],
        'fill' => [
            'fillType' => Fill::FILL_SOLID,
            'startColor' => ['rgb' => 'DDDDDD'],
        ],
    ]);

    // Data rows
    $row = 2;
    foreach ($students as $student) {
        $timeIn = $student['time_in'] ? date("h:i A", strtotime($student['time_in'])) : '';
        $timeOut = $student['time_out'] ? date("h:i A", strtotime($student['time_out'])) : '';

        $sheet->setCellValue("A$row", $student['name']);
        $sheet->setCellValue("B$row", $timeIn);
        $sheet->setCellValue("C$row", $timeOut);

        // Highlight absentees
        if (empty($timeIn) && empty($timeOut)) {
            $sheet->getStyle("A$row:C$row")->applyFromArray([
                'fill' => [
                    'fillType' => Fill::FILL_SOLID,
                    'startColor' => ['rgb' => 'FF0000'],
                ],
                'font' => ['color' => ['rgb' => 'FFFFFF']],
            ]);
        }

        $row++;
    }

    // Auto-size columns
    foreach (range('A', 'C') as $col) {
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }

    $sheetIndex++;
}

// Save the file
$folderPath = 'C:/Attendance_Backups/';
if (!is_dir($folderPath)) {
    mkdir($folderPath, 0777, true);
}

$fileName = "attendance_export_" . date("Y-m-d_H-i-s") . ".xlsx";
$filePath = $folderPath . $fileName;

$writer = new Xlsx($spreadsheet);
$writer->save($filePath);

// Update database: mark exported
if (!empty($studentIdsToMark)) {
    $idList = implode(',', array_map('intval', $studentIdsToMark));

    // Mark as exported
    $conn->query("UPDATE attendance 
                  SET exported = 1, exported_at = NOW() 
                  WHERE student_id IN ($idList) AND date = CURDATE()");

    // Clear time in/out for those records
    $conn->query("UPDATE attendance 
                  SET time_in_am = NULL, time_out_pm = NULL 
                  WHERE student_id IN ($idList) AND date = CURDATE()");
}

// Close connection
$conn->close();

// Done
echo "✅ Exported successfully to <strong>$filePath</strong>";
?>
